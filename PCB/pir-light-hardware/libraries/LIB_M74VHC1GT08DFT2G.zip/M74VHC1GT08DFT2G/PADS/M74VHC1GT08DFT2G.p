*PADS-LIBRARY-PART-TYPES-V9*

M74VHC1GT08DFT2G SOT65P210X110-5N I ANA 9 1 0 0 0
TIMESTAMP 2026.06.17.18.41.24
"Manufacturer_Name" onsemi
"Manufacturer_Part_Number" M74VHC1GT08DFT2G
"Mouser Part Number" 863-M74VHC1GT08DFT2G
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/ON-Semiconductor/M74VHC1GT08DFT2G?qs=3JMERSakebrjhPdWHc0RBw%3D%3D
"Arrow Part Number" M74VHC1GT08DFT2G
"Arrow Price/Stock" https://www.arrow.com/en/products/m74vhc1gt08dft2g/on-semiconductor.html?utm_currency=USD&region=nac
"Description" Wide Operating Vcc Range; High Speed: tPD = 3.5 ns (Typ) at VCC = 5 V; Low Power Dissipation: ICC = 1A (Max) at TA = 25C; TTL-Compatible Inputs: VIL = 0.8 V; VIH = 2.0 V; CMOS-Compatible Outputs: VOH > 0.8 VCC ; VOL < 0.1 VCC @Load; Power Down Protection Provided on Inputs and Outputs; Balanced Propagation Delays; Pin and Function Compatible with Other Standard Logic Families; Chip Complexity: FETs =  100; Pb-Free Packages are Available
"Datasheet Link" https://www.onsemi.com/pub/Collateral/MC74VHC1G08-D.PDF
"Geometry.Height" 1.1mm
GATE 1 5 0
M74VHC1GT08DFT2G
1 0 U IN_B
2 0 U IN_A
3 0 U GND
4 0 U OUT_Y
5 0 U VCC

*END*
*REMARK* SamacSys ECAD Model
373182/1585334/2.50/5/2/Integrated Circuit
