*PADS-LIBRARY-PART-TYPES-V9*

LMV331IDCKR SOT65P210X110-5N I ANA 9 1 0 0 0
TIMESTAMP 2026.06.17.18.50.38
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" LMV331IDCKR
"Mouser Part Number" 595-LMV331IDCKR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/LMV331IDCKR?qs=p6YqzpSxLIzSxSIIlXlZ0w%3D%3D
"Arrow Part Number" LMV331IDCKR
"Arrow Price/Stock" https://www.arrow.com/en/products/lmv331idckr/texas-instruments?utm_currency=USD&region=europe
"Description" Texas Instruments LMV331IDCKR Comparator, Open Collector O/P, 2.7  5.5 V 5-Pin SC-70
"Datasheet Link" http://www.ti.com/lit/gpn/lmv331
"Geometry.Height" 1.1mm
GATE 1 5 0
LMV331IDCKR
1 0 U 1IN+
2 0 U GND
3 0 U 1IN-
4 0 U OUT
5 0 U VCC+

*END*
*REMARK* SamacSys ECAD Model
414996/1585334/2.50/5/3/Integrated Circuit
